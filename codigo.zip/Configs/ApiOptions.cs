﻿namespace WebAgroConnect.Configs;

public sealed class ApiOptions
{
    public string BaseUrl { get; set; } = "";
}